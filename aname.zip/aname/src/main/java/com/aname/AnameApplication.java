package com.aname;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AnameApplication {

	public static void main(String[] args) {
		SpringApplication.run(AnameApplication.class, args);
	}

}
